import React from 'react'
import Head from 'next/head'

import Script from 'dangerous-html/react'

const APPT = (props) => {
  return (
    <>
      <div className="appt-container">
        <Head>
          <title>APPT - UNI-SETU</title>
          <meta property="og:title" content="APPT - UNI-SETU" />
          <meta
            property="og:image"
            content="https://aheioqhobo.cloudimg.io/v7/_playground-bucket-v2.teleporthq.io_/8e1e4122-becd-473f-9615-6186bd64229e/65a48c97-c4ca-4817-97db-9448e90468b8?org_if_sml=1&amp;force_format=original"
          />
        </Head>
        <h1 className="appt-text">UNI-SEVA APPOINTMENT</h1>
        <div className="appt-container1">
          <div className="appt-container2">
            <React.Fragment>
              <React.Fragment>
                <meta
                  name="viewport"
                  content="width=device-width, initial-scale=1"
                />
                <style
                  dangerouslySetInnerHTML={{
                    __html:
                      '\nbody {\n  font-family: Arial, Helvetica, sans-serif;\n  background-color: black;\n}\n\n* {\n  box-sizing: border-box;\n}\n\n/* Add padding to containers */\n.container {\n  padding: 16px;\n  background-color: white;\n}\n\n/* Full-width input fields */\ninput[type=text], input[type=password] {\n  width: 100%;\n  padding: 15px;\n  margin: 5px 0 22px 0;\n  display: inline-block;\n  border: none;\n  background: #f1f1f1;\n}\n\ninput[type=text]:focus, input[type=password]:focus {\n  background-color: #ddd;\n  outline: none;\n}\n\n/* Overwrite default styles of hr */\nhr {\n  border: 1px solid #f1f1f1;\n  margin-bottom: 25px;\n}\n\n/* Set a style for the submit button */\n.registerbtn {\n  background-color: #04AA6D;\n  color: white;\n  padding: 16px 20px;\n  margin: 8px 0;\n  border: none;\n  cursor: pointer;\n  width: 100%;\n  opacity: 0.9;\n}\n\n.registerbtn:hover {\n  opacity: 1;\n}\n\n/* Add a blue text color to links */\na {\n  color: dodgerblue;\n}\n\n/* Set a grey background color and center the text of the "sign in" section */\n.signin {\n  background-color: #f1f1f1;\n  text-align: center;\n}\n',
                  }}
                />

                <form action="/action_page.php">
                  <div className="container">
                    <h1> UNI-SEVA Appointment</h1>
                    <p>
                      Please fill correct detils in this form to appointment
                      otherwise strict action shall be taken against you.
                    </p>
                    <hr />

                    <label htmlFor="Registration Number">
                      <b>Registration No.</b>
                    </label>
                    <input
                      type="text"
                      placeholder="Enter Email"
                      name="email"
                      id="email"
                      required={true}
                    />

                    <label htmlFor="Mobile number">
                      <b>Mobile Number</b>
                    </label>
                    <input
                      type="password"
                      placeholder="Enter Password"
                      name="psw"
                      id="psw"
                      required={true}
                    />

                    <hr />
                    <p>
                      By creating an account you agree to our{' '}
                      <a href="#">Terms & Privacy</a>.
                    </p>

                    <button type="submit" className="registerbtn">
                      Register
                    </button>
                  </div>
                </form>
              </React.Fragment>
            </React.Fragment>
          </div>
        </div>
      </div>
      <style jsx>
        {`
          .appt-container {
            width: 100%;
            display: flex;
            overflow: auto;
            min-height: 100vh;
            align-items: center;
            flex-direction: column;
            justify-content: center;
            background-color: #ffe6e3;
          }
          .appt-text {
            top: -1px;
            left: 470px;
            color: #ea0f0f;
            position: absolute;
          }
          .appt-container1 {
            height: 517px;
          }
          .appt-container2 {
            display: contents;
          }
          @media (max-width: 991px) {
            .appt-text {
              top: 8px;
              left: 233px;
            }
          }
          @media (max-width: 479px) {
            .appt-text {
              top: 2px;
              left: 12px;
            }
          }
        `}
      </style>
    </>
  )
}

export default APPT
