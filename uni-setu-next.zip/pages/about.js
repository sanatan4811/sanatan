import React from 'react'
import Head from 'next/head'

const About = (props) => {
  return (
    <>
      <div className="about-container">
        <Head>
          <title>about - UNI-SETU</title>
          <meta property="og:title" content="about - UNI-SETU" />
          <meta
            property="og:image"
            content="https://aheioqhobo.cloudimg.io/v7/_playground-bucket-v2.teleporthq.io_/8e1e4122-becd-473f-9615-6186bd64229e/65a48c97-c4ca-4817-97db-9448e90468b8?org_if_sml=1&amp;force_format=original"
          />
        </Head>
        <h1 className="about-text">सेवा परमो धर्मः</h1>
        <iframe
          src="https://www.youtube.com/embed/U80_3J_42u8?si=aoJo0iFfZGxnJBhw"
          className="about-iframe"
        ></iframe>
      </div>
      <style jsx>
        {`
          .about-container {
            width: 100%;
            display: flex;
            overflow: auto;
            min-height: 100vh;
            align-items: center;
            flex-direction: column;
            justify-content: center;
          }
          .about-text {
            top: 15px;
            left: 455px;
            color: #e81212;
            position: absolute;
          }
          .about-iframe {
            width: 974px;
            height: 516px;
          }
          @media (max-width: 767px) {
            .about-iframe {
              width: 758px;
              height: 425px;
            }
          }
          @media (max-width: 479px) {
            .about-iframe {
              width: 478px;
              height: 276px;
            }
          }
        `}
      </style>
    </>
  )
}

export default About
